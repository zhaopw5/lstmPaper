# 输入是solar + helium
# 递归
预测值写入字典，供后续递归使用